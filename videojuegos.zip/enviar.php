<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  echo "Formulario recibido correctamente";
}
?>
